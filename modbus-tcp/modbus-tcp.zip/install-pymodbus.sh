# install a specific version (here release v0.1.10)
# sudo pip install pyModbusTCP==v0.1.10

# install a specific version (here release v0.1.10) directly from github servers
# sudo pip install git+https://github.com/sourceperl/pyModbusTCP.git@v0.1.10

# install the last available release (stable)
sudo pip install pyModbusTCP